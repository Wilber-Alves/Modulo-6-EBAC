using UnityEngine;
public interface IDamageable<T>
{
    void Damage(T f);
    void Damage();
    object GetComponent<T1>();
}

public interface IKillable
{
    void Kill();
}
