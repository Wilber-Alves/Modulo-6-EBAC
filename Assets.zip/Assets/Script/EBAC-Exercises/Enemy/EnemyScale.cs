using UnityEngine;
using System.Collections;

public class EnemyScale : EnemyBase
{ 
    #region Variables
    [Header("Enemy Scale")]
    public float scaleFactor = 1.5f;
    public float scaleDuration = 1.0f;
    public MeshRenderer meshRenderer;

    [Space()]
    private bool _attacking = false;
    private Coroutine _currentCoroutineColor;
    private Coroutine _currentCoroutineScale;
    #endregion

    #region Coroutines for Cure Attack (Scale & Color Change)
    public override void Attack()
    {
        base.Attack();

        if (!_attacking)
        {
            _attacking = true;
            transform.localScale *= scaleFactor;
        }

        _currentCoroutineColor ??= StartCoroutine(ChangeColorCoroutine());

        _currentCoroutineScale ??= StartCoroutine(DelayCall());

    }
    public void ResetScale()
    {
        transform.localScale = Vector3.one;
        _attacking = false;
    }

    IEnumerator DelayCall()
    {
        yield return new WaitForSeconds(scaleDuration);

        transform.localScale *= scaleFactor;

        yield return new WaitForSeconds(scaleDuration);

        transform.localScale = Vector3.one;
        _attacking = false;
        _currentCoroutineScale = null;
    }

    IEnumerator ChangeColorCoroutine()
    {
        Debug.Log("I feel better now...");
        for (float i = 1f; i >= 0; i -= 0.01f)
        {
            meshRenderer.material.SetColor(("_BaseColor"), Color.Lerp(Color.white, Color.red, 1 - i));
            yield return new WaitForEndOfFrame();
        }

        yield return new WaitForSeconds(0.01f);

        for (float i = 1f; i >= 0; i -= 0.01f)
        {
            meshRenderer.material.SetColor(("_BaseColor"), Color.Lerp(Color.red, Color.green, 1 - i));
            yield return new WaitForEndOfFrame();
        }

        yield return new WaitForSeconds(0.01f);

        for (float i = 1f; i >= 0; i -= 0.01f)
        {
            meshRenderer.material.SetColor(("_BaseColor"), Color.Lerp(Color.green, Color.cyan, 1 - i));
            yield return new WaitForEndOfFrame();
        }

        yield return new WaitForSeconds(0.01f);

        for (float i = 1f; i >= 0; i -= 0.01f)
        {
            meshRenderer.material.SetColor(("_BaseColor"), Color.Lerp(Color.cyan, Color.white, 1 - i));
            yield return new WaitForEndOfFrame();
        }

        yield return new WaitForSeconds(0.05f);

        _currentCoroutineColor = null;
    }
    #endregion
}
