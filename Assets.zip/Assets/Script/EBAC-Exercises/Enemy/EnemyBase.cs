using UnityEngine;
using static UnityEngine.Rendering.DebugUI;

public class EnemyBase : MonoBehaviour, IKillable, IDamageable<float>
{
    #region Variables

    public EnemySetup enemySetup;
    public float _currentLife;

    #endregion 

    #region Life System
    private void Awake()
    {
        Init();
    }

    protected virtual void Init()
    {
        _currentLife = enemySetup.startLife;
    }
    #endregion

    #region virtual void - |For Cure Attack|
    public virtual void Attack()
    {
        if (_currentLife < 3)
        {
            _currentLife += 1;
        }
    }
    #endregion

    #region Interfaces - |for Punch and Explosion Attack|
    public virtual void OnDamage() { }
    public void Kill() {Destroy(gameObject);}

    public void Damage(float f) 
    {
        _currentLife -= f;
        transform.localScale *= 0.9f;
        OnDamage(); 
        if (_currentLife <= 0)
        {
            Kill();
        }
    }

    public void Damage() {Damage(2f); } // The hard code for this line represents the damage value of the explosion, causing 2 points of damage.

    object IDamageable<float>.GetComponent<T1>()
    {
        return this.GetComponent<T1>();
    }
    #endregion
}
