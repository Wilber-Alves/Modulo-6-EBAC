using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;


public class ScriptTest : MonoBehaviour

{
    #region Variables
    public enum Attacks
    {
        None,
        Punch,
        Cure,
        Explosion
    }
    public Attacks enemyAttack;
    
    public UnityEvent eventCallback;
    
    public EnemyBase enemyBase;
    public EnemySetup enemySetup;

    public List<IDamageable<float>> damageablesList;
    public List<GameObject> damageablesGameObjectList;

    private Coroutine _currentCoroutineColorDamageable;
    public MeshRenderer meshRenderer;

    #endregion

    #region Methods

    #region Start, Update and Explosion Attack Methods

    void Start()

    {
        print("Module 5 - Exercise EBAC - " + "|(Press Z key for punch)|" + "|(Press X key for cure)|" + "|(Press C key for explosion)|");
    }
    
    private void Update()
    {
        CheckSwitchCase(enemyAttack); 
        CheckKeys();
    }
   
    private void Attack()
    {
        foreach (var o in damageablesGameObjectList)
        {
            if (o != null)
            {
                var damageable = o.GetComponent<IDamageable<float>>();
                damageable.Damage();
                _currentCoroutineColorDamageable ??= StartCoroutine(ColorDamagebleCoroutine());
            }
        }
        Debug.Log("BOOOOOMMMM!!!!!!");
    }

    #endregion

    #region CheckSwitchCase and CheckKeys Methods
    private void CheckSwitchCase (Attacks a)
    {
        switch (a)
        {
            case Attacks.Punch:
                OnReadPunch();
                break;
            case Attacks.Cure:
                OnReadCure();
                break;
            case Attacks.Explosion:
                OnReadExplosion();
                break;
            default:
                OnReadNone();
                break;
        }
    }

    private void CheckKeys()
    {
        if (Input.GetKeyDown(KeyCode.Z))
        {
            eventCallback.Invoke();
            CheckSwitchCase(Attacks.Punch);
        }
        else if (Input.GetKeyDown(KeyCode.X))
        {
            enemyBase.Attack();
            CheckSwitchCase(Attacks.Cure);
        }
        else if (Input.GetKeyDown(KeyCode.C))
        {
            Attack();
            CheckSwitchCase(Attacks.Explosion);
        }
    }
    #endregion

    #region OnRead Methods for the CheckSwitchCase and CheckKeys methods.
   
    private void OnReadPunch()
    {
        Debug.Log("Punch! - " + "Passive enemy lost 1 life point");
    }
    private void OnReadCure()
    {
        Debug.Log("Cure! - " + "Reactive enemy cures yourself! Recovered 1 life point!");
    }
    private void OnReadExplosion()
    {
        Debug.Log("Explosion! - " + "Reactive enemy causes a big explosion! Everybody lost 2 life point!");
    }
    private void OnReadNone()
    {
        Debug.Log("Fight out!");
    }
    #endregion

    #region Colour Damageable Coroutine for explosion attack
    IEnumerator ColorDamagebleCoroutine()
    {
        for (float i = 1f; i >= 0; i -= 0.01f)
        {
            meshRenderer.material.SetColor(("_BaseColor"), Color.Lerp(Color.white, enemySetup.colorDamageable, 1 - i));
            yield return new WaitForEndOfFrame();
        }

        yield return new WaitForSeconds(0.05f);

        for (float i = 1f; i >= 0; i -= 0.01f)
        {
            meshRenderer.material.SetColor(("_BaseColor"), Color.Lerp(enemySetup.colorDamageable, Color.black, 1 - i));
            yield return new WaitForEndOfFrame();
        }

        yield return new WaitForSeconds(0.05f);

        _currentCoroutineColorDamageable = null;
    }
    #endregion
    #endregion
}

