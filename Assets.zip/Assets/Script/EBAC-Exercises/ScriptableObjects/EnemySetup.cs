using UnityEngine;

[CreateAssetMenu]

public class EnemySetup : ScriptableObject
{
    public float startLife = 5;
    public float force = 10;

    [Header("Color Change")]
    public Color colorDamageable = Color.white;
}
