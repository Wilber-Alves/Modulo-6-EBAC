﻿public class GameObjectTag
{
}