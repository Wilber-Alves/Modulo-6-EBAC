using UnityEngine;

public class CheckCollision : MonoBehaviour
{
    public GameObject door;

    private void Awake() => door.SetActive(true);

    private void OnTriggerEnter(Collider other)
    {
        door.SetActive(false);
    }
}

