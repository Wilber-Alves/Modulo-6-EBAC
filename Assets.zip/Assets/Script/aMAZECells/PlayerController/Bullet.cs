using System;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public GameObject _bulletToSpawn;
    [SerializeField, Tooltip("Speed of this bullet.")]
    private float _speed = 4f;
    [SerializeField, Tooltip("Normalized direction of this bullet.")]
    private Vector3 _direction = Vector3.zero;
    // public float timeToDestroy = 0.5f;
    public float timeToReset = 0.5f;
    private float _rotationSpeed = 5000.0f;

    public string tagToLook = "Enemy";

    public Action OnHitTarget;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        // move the bullet 
        Vector3 newPos = transform.position;
        newPos += _direction * (_speed * Time.deltaTime);
        transform.position = newPos;

        // rotate the bullet
        Vector3 newRotation = transform.eulerAngles;
        newRotation.z += (_rotationSpeed * Time.deltaTime);
        transform.eulerAngles = newRotation;
    }
    public void SetDirection(Vector3 direction)
    {
        _direction = direction;

        // rotate to face the direction of movement
        transform.LookAt(transform.position + _direction);

    }

    public void Awake()
    {
        // Destroy(_bulletToSpawn, timeToDestroy);
    }
    public void StartBullet()
    {
        Invoke(nameof(FinishUsage), timeToReset);
    }
    private void FinishUsage()
    {
         _bulletToSpawn.SetActive(false);
          OnHitTarget = null;
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.transform.CompareTag(tagToLook))
        {
            Destroy(collision.gameObject);
            OnHitTarget?.Invoke();
            FinishUsage();
        }
    }
}
