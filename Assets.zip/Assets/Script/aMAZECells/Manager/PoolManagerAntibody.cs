using System.Collections.Generic;
using UnityEngine;

public class PoolManagerAntibody : MonoBehaviour
{
    public GameObject antibody;
    public List<GameObject> pooledObjects;
    public int amount = 30;
    private void Awake()
    {
        StartPool();
    }

    private void StartPool()
    {
        pooledObjects = new List<GameObject>();
        for (int i = 0; i < amount; i++)
        {
            var obj = Instantiate(antibody, transform);
            obj.SetActive(false);
            pooledObjects.Add(obj);
        }
    }
    public GameObject GetPooledObject()
    {
        for (int i = 0; i < amount; i++)
        {
            if (!pooledObjects[i].activeInHierarchy)
            {
                return pooledObjects[i];
            }
        }
        return null;
    }
}