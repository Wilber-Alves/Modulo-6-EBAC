using UnityEngine;

public class PlayerInventory : MonoBehaviour
{
    public bool hasSubstrate = false;
}
